//
//  Message.swift
//  Flash Chat iOS13
//
//  Created by Mely on 18.10.2021.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import Foundation
struct Message{
    let sender:String//email adrees of sender
    let body:String
    
}
