//
//  ChatViewController.swift
//  Flash Chat iOS13
//
//  Created by Angela Yu on 21/10/2019.
//  Copyright © 2019 Angela Yu. All rights reserved.
//

import UIKit
import Firebase

class ChatViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var messageTextfield: UITextField!
    
    //reference our database
    let db = Firestore.firestore()
    
    //creat a messages variable with array
//    var messages:[Message] = [
//        Message(sender: "mehlika@2.com",body:"Hello :)"),
//        Message(sender: "john@2.com",body:"How are you?"),
//        Message(sender: "kate@2.com",body:"Good day!")
//    ]
    //icini bosalttik cunku canli mesaj alcaz biri yazcak biz bunun icine koycaz
    var messages:[Message] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        title = K.appName
        navigationItem.hidesBackButton = true
        
        //mavi me button olan labeli yapinca burada gostermek icin cagirdik
        tableView.register(UINib(nibName: K.cellNibName, bundle: nil), forCellReuseIdentifier: K.cellIdentifier)
        
        //it will call current data in our database
        loadMessages()

    }
    
    func loadMessages() {
        
        //querySnapshot is body of database
        db.collection(K.FStore.collectionName)
            .order(by: K.FStore.dateField)
            .addSnapshotListener { (querySnapshot, error) in
            
            self.messages = []
            
            if let e = error {
                print("There was an issue retrieving data from Firestore. \(e)")
            } else {
                if let snapshotDocuments = querySnapshot?.documents {
                    for doc in snapshotDocuments {
                        let data = doc.data()
                        if let messageSender = data[K.FStore.senderField] as? String, let messageBody = data[K.FStore.bodyField] as? String {
                            let newMessage = Message(sender: messageSender, body: messageBody)
                            //adding fresh messages into array
                            self.messages.append(newMessage)
                    
                            DispatchQueue.main.async {
                                //it will be able to trigger data we have in body
                                   self.tableView.reloadData()
                                let indexPath = IndexPath(row: self.messages.count - 1, section: 0)
                                self.tableView.scrollToRow(at: indexPath, at: .top, animated: false)
                            }
                        }
                    }
                }
            }
        }
    }
    //when the users click the send button
    @IBAction func sendPressed(_ sender: UIButton) {
        
        //if  messageTextfield.text bos degilse save to messagebodye
        if let messageBody = messageTextfield.text,
            //burada current login yapan kisi  i yaziyor yoksa baska birimi onu check ediyoruz
           let messageSender = Auth.auth().currentUser?.email {
            //add data to firebase
            db.collection(K.FStore.collectionName).addDocument(data: [
                K.FStore.senderField: messageSender,
                K.FStore.bodyField: messageBody,
                K.FStore.dateField: Date().timeIntervalSince1970//mesajalri sirasiyla dizecek son gonderdigimiz son gidecek ilk gonderdigimiz en basta olacak
            ]) { (error) in
                if let e = error {
                    print("There was an issue saving data to firestore, \(e)")
                } else {
                    print("Successfully saved data.")
                    
                    DispatchQueue.main.async {
                         self.messageTextfield.text = ""
                       
                    }
                }
            }
        }
    }
    
    @IBAction func logOutPressed(_ sender: UIBarButtonItem) {
    do {
      try Auth.auth().signOut()
        //signout yapinca bizi en bastaki giris sayfasina goturuyotr
        navigationController?.popToRootViewController(animated: true)
    } catch let signOutError as NSError {
      print("Error signing out: %@", signOutError)
    }
      
    }
    

}

//this is for it is going to request the data
//burada bize login yaptigimzda mesaj kisminda mesajlari ekrana getirecek ve gormemizi saglayacak yer
extension ChatViewController : UITableViewDataSource{
    //whic data we show
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let message = messages[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: K.cellIdentifier, for: indexPath)
        as! MessageCell
        cell.label.text = message.body

        //if the sender is the same who loged in the app
        //this is a message from a current user
        if message.sender == Auth.auth().currentUser?.email{
            //lefti gostreme yani you olani me olani goster diyosun
            cell.leftImageView.isHidden = true
            cell.rightImageView.isHidden
             = false
            cell.messageBubble.backgroundColor = UIColor(named:K.BrandColors.lightPurple)
            cell.label.textColor = UIColor(named:K.BrandColors.purple)
        }
        //if this is messager another sender who is not a user logged in the app
        else{
            cell.leftImageView.isHidden = false
            cell.rightImageView.isHidden = true
             
            cell.messageBubble.backgroundColor = UIColor(named:K.BrandColors.purple)
            cell.label.textColor = UIColor(named:K.BrandColors.lightPurple)
        }
//        let cell = tableView.dequeueReusableCell(withIdentifier: K.cellIdentifier, for: indexPath)
        //forced downcast
        //as! MessageCell
        //mesela burada this is a cell yazisi 3 defa cikiyor ekrana
        //cell.textLabel?.text = "This is a cell"
        
        //bunu yapinca 0 1 2 yani row numberlarini aliyoruz
        //cell.textLabel?.text = "\(indexPath.row)"
        
        //simdi ise mesajimizin body yani icinde ne azdigini gorecegiz hello whatup gibi gibi
        //cell.textLabel?.text = messages[indexPath.row].body
        //cell.label.text = message.body
        
        return cell
    }
    //how many cell we need
    func tableView(_ tableView: UITableView, numberOfRowsInSection section:Int) -> Int {
        return messages.count
    }

}

extension ChatViewController : UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        //we see cell numbers in the console when we click the messages
        // ama mesaja bastigimzda tabiki bisey olmamali  u yuzden maine gidip selctore none yaptik cunku mesaja dokundugumiuzda bisey degsiisin istemiyoruz
        print(indexPath.row)
    }
}
